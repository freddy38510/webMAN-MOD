// gccpch.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently.
// gccpch.h.gch will contain the pre-compiled type information
//

#ifndef __GCCPCH__
#define __GCCPCH__

// TODO: reference additional headers your program requires here

#endif
