#include <stdlib.h>
#include <stdio.h>
#include "include\ntfs.h"

ntfs_md *mounts;
int mountCount;


int main ()
{

	mountCount = ntfsMountAll(&mounts, NTFS_DEFAULT | NTFS_RECOVER | NTFS_READ_ONLY);
	return 0;
	//if (mountCount <= 0) 

/*	int i=0;
   	ntfs_md *mounts[8] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
	char *cur_device = "/ntfs0:";
	int k=0;
	sprintf("%s - %s:/ (%s) (from usb00%i)\n",(const char *) "1", 
    (mounts[0])->name, ntfsGetVolumeName((mounts[0])->name), 
    ((mounts[0])->interface->ioType & 0xff) - '0');
	return 0;	
	*/
}